// Supabase Edge Function: email-versand
// Benötigte Secrets:
// RESEND_API_KEY=...
// EMAIL_FROM=Pausenapp <onboarding@resend.dev>

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const EMAIL_FROM = Deno.env.get('EMAIL_FROM') || 'Pausenapp <onboarding@resend.dev>';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

function money(value: number) {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(Number(value || 0));
}

function renderProducts(products: any[] = []) {
  if (!products.length) return '<p>Keine Produktdetails vorhanden.</p>';
  return `<ul>${products.map((p) => `<li>${p.quantity || 1}x ${p.name} - ${money(p.price || p.unit_price || 0)}</li>`).join('')}</ul>`;
}

async function sendEmail({ to, subject, html }: { to: string | string[]; subject: string; html: string }) {
  if (!RESEND_API_KEY) throw new Error('RESEND_API_KEY fehlt in den Supabase Secrets.');
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: EMAIL_FROM, to, subject, html })
  });
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { type, payload } = await req.json();
    if (!type || !payload) throw new Error('type und payload sind erforderlich.');

    let to: string | string[] = payload.parentEmail || payload.adminEmail;
    let subject = 'Pausenapp';
    let html = '<p>Pausenapp Nachricht</p>';

    if (type === 'order_confirmation') {
      to = [payload.parentEmail, payload.adminEmail].filter(Boolean);
      subject = `Pausenapp Bestellung ${payload.paymentReference || payload.orderId}`;
      html = `
        <h2>Bestellung gespeichert</h2>
        <p><b>Eltern:</b> ${payload.parentName} (${payload.parentEmail})</p>
        <p><b>Kind:</b> ${payload.childName}</p>
        <p><b>Schule/Klasse:</b> ${payload.school || ''} ${payload.className || ''}</p>
        <p><b>Tag:</b> ${payload.weekday}</p>
        <p><b>Lieferdatum:</b> ${payload.deliveryDate || ''}</p>
        <p><b>Zahlungsart:</b> ${payload.paymentMethod}</p>
        <p><b>Status:</b> ${payload.status}</p>
        <p><b>Gesamt:</b> ${money(payload.total)}</p>
        <p><b>Verwendungszweck:</b> ${payload.paymentReference || '-'}</p>
        ${renderProducts(payload.products)}
      `;
    }

    if (type === 'payment_confirmed') {
      to = payload.parentEmail;
      subject = `Zahlung bestätigt - ${payload.paymentReference || payload.orderId}`;
      html = `
        <h2>Zahlung bestätigt</h2>
        <p>Hallo ${payload.parentName},</p>
        <p>die Zahlung für die Bestellung von <b>${payload.childName}</b> wurde bestätigt.</p>
        <p><b>Betrag:</b> ${money(payload.total)}</p>
        <p><b>Verwendungszweck:</b> ${payload.paymentReference || '-'}</p>
      `;
    }

    if (type === 'payment_reminder') {
      to = payload.parentEmail;
      subject = `Zahlung offen - ${payload.paymentReference || 'Pausenapp'}`;
      html = `
        <h2>Zahlung noch offen</h2>
        <p>Hallo ${payload.parentName},</p>
        <p>für die Bestellung von <b>${payload.childName}</b> ist noch eine Zahlung offen.</p>
        <p><b>Tag:</b> ${payload.weekday || ''}</p>
        <p><b>Betrag:</b> ${money(payload.total)}</p>
        <p><b>Zahlungsart:</b> ${payload.paymentMethod}</p>
        <p><b>Verwendungszweck:</b> ${payload.paymentReference || '-'}</p>
        <p>Bitte gib den Verwendungszweck exakt an.</p>
      `;
    }

    if (type === 'deadline_reminder') {
      to = payload.parentEmail;
      subject = 'Reminder: Bestellfrist endet bald';
      html = `
        <h2>Bestellfrist Erinnerung</h2>
        <p>Hallo ${payload.parentName},</p>
        <p>die Bestellfrist für <b>${payload.weekday}</b> endet:</p>
        <p><b>${payload.deadline}</b></p>
        <p>Bitte rechtzeitig bestellen.</p>
      `;
    }

    if (type === 'bakery_production_list') {
      to = [payload.bakeryEmail, payload.adminEmail].filter(Boolean);
      subject = `Produktionsliste ${payload.weekday} - Pausenapp`;
      const products = (payload.products || []).map((p: any) => `<tr><td>${p.name}</td><td>${p.quantity}</td></tr>`).join('');
      const orders = (payload.orders || []).map((o: any) => `<tr><td>${o.childName}</td><td>${o.className || ''}</td><td>${o.allergies || 'keine'}</td><td>${(o.items || []).join(', ')}</td><td>${o.paymentReference || ''}</td></tr>`).join('');
      html = `
        <h2>Produktionsliste ${payload.weekday}</h2>
        <p><b>Lieferdatum:</b> ${payload.deliveryDate || ''}</p>
        <h3>Zusammenfassung</h3>
        <table border="1" cellpadding="6"><thead><tr><th>Produkt</th><th>Menge</th></tr></thead><tbody>${products}</tbody></table>
        <h3>Details</h3>
        <table border="1" cellpadding="6"><thead><tr><th>Kind</th><th>Klasse</th><th>Allergien</th><th>Produkte</th><th>Referenz</th></tr></thead><tbody>${orders}</tbody></table>
      `;
    }

    if (!to) throw new Error('Empfänger fehlt.');

    const result = await sendEmail({ to, subject, html });
    return new Response(JSON.stringify({ ok: true, result }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error) {
    return new Response(JSON.stringify({ ok: false, error: error.message }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
