-- Basis-Schema fuer Pausenapp
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  role text default 'parent' check (role in ('parent', 'admin')),
  created_at timestamptz default now()
);

create table if not exists children (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references auth.users(id) on delete cascade,
  name text not null,
  school text not null default 'Grundschule Zentrum',
  class_name text,
  allergies text default 'keine',
  created_at timestamptz default now()
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(10,2) not null default 0,
  tags text[] default '{}',
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references auth.users(id) on delete cascade,
  child_id uuid references children(id) on delete set null,
  school text,
  delivery_date date,
  weekday text,
  total numeric(10,2) not null default 0,
  payment_method text default 'Überweisung',
  payment_reference text,
  status text default 'offen',
  confirmation_email_sent boolean default false,
  bakery_email_sent boolean default false,
  created_at timestamptz default now()
);

create table if not exists order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id) on delete cascade,
  product_id uuid references products(id) on delete set null,
  product_name text not null,
  quantity integer default 1,
  unit_price numeric(10,2) not null default 0,
  created_at timestamptz default now()
);

alter table profiles enable row level security;
alter table children enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

create policy if not exists "profiles own read" on profiles for select using (auth.uid() = id);
create policy if not exists "profiles own update" on profiles for update using (auth.uid() = id);

create policy if not exists "children own all" on children for all using (auth.uid() = parent_id) with check (auth.uid() = parent_id);

create policy if not exists "products readable" on products for select using (active = true);
create policy if not exists "products admin all" on products for all using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')) with check (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));

create policy if not exists "orders own all" on orders for all using (auth.uid() = parent_id) with check (auth.uid() = parent_id);
create policy if not exists "orders admin all" on orders for all using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')) with check (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));

create policy if not exists "order_items own read" on order_items for select using (exists (select 1 from orders o where o.id = order_id and o.parent_id = auth.uid()));
create policy if not exists "order_items own insert" on order_items for insert with check (exists (select 1 from orders o where o.id = order_id and o.parent_id = auth.uid()));
create policy if not exists "order_items admin all" on order_items for all using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin')) with check (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));
