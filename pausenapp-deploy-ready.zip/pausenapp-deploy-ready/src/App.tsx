import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { env, isSupabaseConfigured, supabase } from '@/lib/supabase';

type Product = { id: string; name: string; price: number; tags: string[]; desc: string; active?: boolean };
type Child = { id: string; name: string; school: string; className: string; allergies: string };
type OrderMap = Record<string, Record<string, string[]>>;
type CompletedOrder = {
  id: string;
  parent: string;
  parentEmail: string;
  child: string;
  school: string;
  day: string;
  total: number;
  payment: string;
  paymentReference: string;
  status: 'offen' | 'bezahlt' | string;
  email: 'vorgemerkt' | 'gesendet' | string;
};

const ADMIN_EMAIL = env.adminEmail;
const ADMIN_NAME = env.adminName;
const BAKERY_EMAIL = env.bakeryEmail;
const PAYPAL_PAYMENT_LINK = env.paypalLink;
const BANK_RECIPIENT = env.bankRecipient;
const BANK_IBAN = env.bankIban;
const BANK_BIC = env.bankBic;
const EMAIL_FUNCTION_NAME = env.emailFunctionName;
const BANK_REFERENCE_PREFIX = 'PAUSE';

const weekdays = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag'];
const paymentMethods = ['Überweisung', 'PayPal', 'Stripe', 'Kreditkarte'];
const livePaymentMethods = ['Überweisung', 'PayPal'];
const ORDER_DEADLINE_HOUR = 18;
const ORDER_DEADLINE_MINUTE = 0;

const demoUser = { id: 'admin-001', name: ADMIN_NAME, email: ADMIN_EMAIL, role: 'admin' };

const fallbackProducts: Product[] = [
  { id: 'laugen-schinken-kaese', name: 'Laugenbrot mit Schinken & Käse', price: 3.2, tags: ['klassisch'], desc: 'Beliebtes Pausenbrot mit Schinken und Käse.' },
  { id: 'laugen-speck-kaese', name: 'Laugenbrot mit Speck & Käse', price: 3.4, tags: ['herzhaft'], desc: 'Kräftig im Geschmack.' },
  { id: 'laugen-lyoner-kaese', name: 'Laugenbrot mit Lyoner & Käse', price: 3.1, tags: ['klassisch'], desc: 'Mildes Pausenbrot mit Lyoner und Käse.' },
  { id: 'semmel-schinken-kaese', name: 'Semmel mit Schinken & Käse', price: 2.8, tags: ['klassisch'], desc: 'Klassische Semmel für die Pause.' },
  { id: 'apfel', name: 'Apfel', price: 1.0, tags: ['vegan', 'frisch'], desc: 'Frischer Apfel, saisonal.' },
  { id: 'banane', name: 'Banane', price: 1.1, tags: ['vegan', 'frisch'], desc: 'Reife Banane als gesunder Snack.' },
  { id: 'wasser', name: 'Mineralwasser klein', price: 1.1, tags: ['getränk'], desc: '0,33 l Wasser ohne Zuckerzusatz.' }
];

const initialChildren: Child[] = [
  { id: 'lena', name: 'Lena', school: 'Grundschule Zentrum', className: '2B', allergies: 'keine' },
  { id: 'max', name: 'Max', school: 'Grundschule Zentrum', className: '4A', allergies: 'Haselnüsse' }
];

const initialOrders: OrderMap = {
  lena: { Montag: ['laugen-schinken-kaese', 'apfel'], Dienstag: ['wasser'] },
  max: { Montag: ['laugen-speck-kaese', 'banane'], Mittwoch: ['apfel'] }
};

const initialCompletedOrders: CompletedOrder[] = [
  { id: 'ord-1001', parent: ADMIN_NAME, parentEmail: ADMIN_EMAIL, child: 'Lena', school: 'Grundschule Zentrum', day: 'Montag', total: 4.2, payment: 'Stripe', paymentReference: '', status: 'bezahlt', email: 'vorgemerkt' },
  { id: 'ord-1002', parent: ADMIN_NAME, parentEmail: ADMIN_EMAIL, child: 'Max', school: 'Grundschule Zentrum', day: 'Montag', total: 4.5, payment: 'PayPal', paymentReference: '', status: 'bezahlt', email: 'vorgemerkt' },
  { id: 'ord-1003', parent: ADMIN_NAME, parentEmail: ADMIN_EMAIL, child: 'Lena', school: 'Grundschule Zentrum', day: 'Dienstag', total: 3.8, payment: 'Überweisung', paymentReference: 'PAUSE-DEMO-LENA', status: 'offen', email: 'vorgemerkt' }
];

function money(value: number) {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(value || 0);
}

function slugify(value: string) {
  return String(value)
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ä/g, 'ae')
    .replace(/ö/g, 'oe')
    .replace(/ü/g, 'ue')
    .replace(/ß/g, 'ss')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function isUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value));
}

function getNetworkErrorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : String(error || 'Unbekannter Fehler');
  if (message.includes('Failed to fetch') || message.includes('fetch')) return 'Netzwerkfehler: Supabase ist gerade nicht erreichbar. App läuft lokal weiter.';
  return message;
}

function normalizeProduct(product: any): Product {
  return { id: product.id, name: product.name, price: Number(product.price || 0), tags: Array.isArray(product.tags) ? product.tags : [], desc: product.desc || product.description || '', active: product.active !== false };
}

function normalizeChild(child: any): Child {
  return { id: child.id, name: child.name, school: child.school, className: child.class_name || child.className || '', allergies: child.allergies || 'keine' };
}

function normalizeCompletedOrder(order: any, child: Child | undefined, user: any): CompletedOrder {
  return {
    id: order.id,
    parent: user?.name || demoUser.name,
    parentEmail: user?.email || demoUser.email,
    child: child?.name || 'Kind',
    school: order.school || child?.school || '',
    day: order.weekday,
    total: Number(order.total || 0),
    payment: order.payment_method || 'Überweisung',
    paymentReference: order.payment_reference || '',
    status: order.status || 'offen',
    email: order.confirmation_email_sent ? 'gesendet' : 'vorgemerkt'
  };
}

function getNextDeliveryDate(weekday: string) {
  const weekdayIndex = weekdays.indexOf(weekday);
  const today = new Date();
  const todayIndex = today.getDay() === 0 ? 6 : today.getDay() - 1;
  const daysToAdd = weekdayIndex >= todayIndex ? weekdayIndex - todayIndex : 7 - todayIndex + weekdayIndex;
  const deliveryDate = new Date(today);
  deliveryDate.setDate(today.getDate() + daysToAdd);
  return deliveryDate.toISOString().slice(0, 10);
}

function getOrderDeadlineDate(weekday: string) {
  const deliveryDate = new Date(`${getNextDeliveryDate(weekday)}T00:00:00`);
  const deadline = new Date(deliveryDate);
  deadline.setDate(deliveryDate.getDate() - 1);
  deadline.setHours(ORDER_DEADLINE_HOUR, ORDER_DEADLINE_MINUTE, 0, 0);
  return deadline;
}

function isOrderDeadlineOpen(weekday: string, now = new Date()) {
  return now.getTime() <= getOrderDeadlineDate(weekday).getTime();
}

function formatOrderDeadline(weekday: string) {
  return getOrderDeadlineDate(weekday).toLocaleString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function getReminderMessage(weekday: string, now = new Date()) {
  const deadline = getOrderDeadlineDate(weekday);
  const diffMs = deadline.getTime() - now.getTime();
  const diffHours = Math.ceil(diffMs / (1000 * 60 * 60));
  if (diffMs < 0) return `Bestellungen für ${weekday} sind fixiert.`;
  if (diffHours <= 3) return `Reminder: Bestellfrist für ${weekday} endet bald.`;
  if (diffHours <= 24) return `Reminder: Bestellfrist für ${weekday} endet heute bzw. morgen.`;
  return `Bestellfrist für ${weekday}: ${formatOrderDeadline(weekday)}`;
}

function calculateChildDayTotal(childId: string, day: string, orderMap: OrderMap, productList: Product[]) {
  return (orderMap[childId]?.[day] || []).reduce((sum, id) => sum + (productList.find((product) => product.id === id)?.price || 0), 0);
}

function calculateWeeklyTotal(orderMap: OrderMap, productList: Product[]) {
  return Object.values(orderMap).flatMap((childOrders) => Object.values(childOrders).flat()).reduce((sum, id) => sum + (productList.find((product) => product.id === id)?.price || 0), 0);
}

function buildSchoolRows(childrenList: Child[], orderMap: OrderMap, day: string, productList: Product[]) {
  return childrenList.flatMap((child) => {
    const itemIds = orderMap[child.id]?.[day] || [];
    if (!itemIds.length) return [];
    return [{ child, items: itemIds.map((id) => productList.find((product) => product.id === id)?.name).filter(Boolean), total: calculateChildDayTotal(child.id, day, orderMap, productList) }];
  });
}

function buildProductSummary(childrenList: Child[], orderMap: OrderMap, day: string, productList: Product[]) {
  const summary: Record<string, { product: string; quantity: number }> = {};
  childrenList.forEach((child) => {
    (orderMap[child.id]?.[day] || []).forEach((productId) => {
      const product = productList.find((item) => item.id === productId);
      if (!product) return;
      if (!summary[product.id]) summary[product.id] = { product: product.name, quantity: 0 };
      summary[product.id].quantity += 1;
    });
  });
  return Object.values(summary);
}

function getNavigationItems(user: any) {
  const baseItems = [['start', 'home', 'Start'], ['bestellen', 'basket', 'Bestellen'], ['kinder', 'user', 'Kinder'], ['zahlung', 'payment', 'Zahlung'], ['statistiken', 'chart', 'Statistiken'], ['schule', 'school', 'Ausgabe']];
  return user?.role === 'admin' ? [...baseItems, ['admin', 'admin', 'Admin']] : baseItems;
}

function createPaymentReference({ child, day, createdAt = new Date() }: { child: Child; day: string; createdAt?: Date }) {
  const datePart = createdAt.toISOString().slice(2, 10).replace(/-/g, '');
  const childPart = slugify(child?.name || 'kind').replace(/-/g, '').slice(0, 6).toUpperCase() || 'KIND';
  const dayPart = String(day || 'tag').slice(0, 2).toUpperCase();
  const randomPart = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${BANK_REFERENCE_PREFIX}-${datePart}-${childPart}-${dayPart}-${randomPart}`;
}

function filterOrdersBySearch(ordersList: CompletedOrder[], searchTerm: string) {
  const term = String(searchTerm || '').trim().toLowerCase();
  if (!term) return ordersList;
  return ordersList.filter((order) => [order.id, order.parent, order.parentEmail, order.child, order.school, order.day, order.payment, order.paymentReference, order.status, money(order.total)].filter(Boolean).some((value) => String(value).toLowerCase().includes(term)));
}

function getParentOrderStats(ordersList: CompletedOrder[]) {
  return {
    count: ordersList.length,
    openCount: ordersList.filter((order) => order.status === 'offen').length,
    paidCount: ordersList.filter((order) => order.status === 'bezahlt').length,
    openTotal: ordersList.filter((order) => order.status === 'offen').reduce((sum, order) => sum + order.total, 0),
    paidTotal: ordersList.filter((order) => order.status === 'bezahlt').reduce((sum, order) => sum + order.total, 0)
  };
}

function buildOrderEmailPayload({ order, child, day, selectedProducts }: { order: CompletedOrder; child: Child; day: string; selectedProducts: Product[] }) {
  return {
    orderId: order.id,
    parentName: order.parent,
    parentEmail: order.parentEmail,
    adminEmail: ADMIN_EMAIL,
    bakeryEmail: BAKERY_EMAIL,
    childName: child.name,
    school: child.school,
    className: child.className,
    allergies: child.allergies || 'keine',
    weekday: day,
    deliveryDate: getNextDeliveryDate(day),
    paymentMethod: order.payment,
    status: order.status,
    paymentReference: order.paymentReference || '',
    total: order.total,
    products: selectedProducts.map((product) => ({ name: product.name, price: product.price, quantity: 1 }))
  };
}

function createUserFromProfile(authUser: any, profile: any) {
  return { id: authUser.id, name: profile?.full_name || authUser.email || demoUser.name, email: profile?.email || authUser.email || demoUser.email, role: profile?.role || 'parent' };
}

function functionNeedsRealUser(user: any) {
  return Boolean(user?.id && isUuid(user.id));
}

function Icon({ name, className = 'h-4 w-4' }: { name: string; className?: string }) {
  const icons: Record<string, string> = { home: '🏠', utensils: '🥪', basket: '🧺', user: '👧', school: '🏫', check: '✓', plus: '+', chevron: '›', admin: '⚙️', chart: '📊', mail: '✉️', payment: '💳', menu: '🍴', orders: '📋', children: '👨‍👩‍👧‍👦', clock: '⏰', salad: '🥗', euro: '€', bell: '🔔', calendar: '📅', warning: '⚠️' };
  return <span className={`inline-flex items-center justify-center leading-none ${className}`} aria-hidden="true">{icons[name] || '•'}</span>;
}

function StatCard({ label, value, hint, icon, tone = 'slate' }: { label: string; value: React.ReactNode; hint: string; icon: string; tone?: string }) {
  const toneClass: Record<string, string> = {
    violet: 'from-violet-50 to-white ring-violet-100 text-violet-700',
    emerald: 'from-emerald-50 to-white ring-emerald-100 text-emerald-700',
    orange: 'from-orange-50 to-white ring-orange-100 text-orange-700',
    blue: 'from-blue-50 to-white ring-blue-100 text-blue-700',
    slate: 'from-slate-50 to-white ring-slate-100 text-slate-700'
  };
  return <Card className={`rounded-[1.5rem] border-0 bg-gradient-to-br ${toneClass[tone] || toneClass.slate} shadow-sm ring-1`}><CardContent className="p-6"><div className="mb-5 flex items-start justify-between gap-3"><span className="rounded-2xl bg-white/80 p-3 text-2xl shadow-sm"><Icon name={icon} className="h-7 w-7" /></span><span className="text-sm font-semibold text-slate-500">{label}</span></div><p className="text-4xl font-black tracking-tight text-slate-950">{value}</p><p className="mt-3 text-sm font-medium text-slate-500">{hint}</p></CardContent></Card>;
}

function QuickActionCard({ icon, title, desc, onClick, tone = 'orange' }: { icon: string; title: string; desc: string; onClick: () => void; tone?: string }) {
  const toneClass: Record<string, string> = { orange: 'from-orange-50 to-white ring-orange-100', yellow: 'from-yellow-50 to-white ring-yellow-100', blue: 'from-blue-50 to-white ring-blue-100', violet: 'from-violet-50 to-white ring-violet-100', emerald: 'from-emerald-50 to-white ring-emerald-100', slate: 'from-slate-50 to-white ring-slate-100' };
  return <button onClick={onClick} className={`group rounded-[1.5rem] bg-gradient-to-br ${toneClass[tone] || toneClass.slate} p-5 text-left shadow-sm ring-1 transition hover:-translate-y-1 hover:shadow-md`}><span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/80 text-3xl shadow-sm"><Icon name={icon} className="h-8 w-8" /></span><p className="mt-5 font-extrabold text-slate-950">{title}</p><p className="mt-2 min-h-[44px] text-sm leading-relaxed text-slate-600">{desc}</p><div className="mt-5 flex justify-end text-2xl text-slate-400 transition group-hover:translate-x-1 group-hover:text-slate-900">→</div></button>;
}

function ParentHome({ children, orders, completedOrders, onNavigate, onSelectChild, onSelectDay }: { children: Child[]; orders: OrderMap; completedOrders: CompletedOrder[]; onNavigate: (tab: string) => void; onSelectChild: (id: string) => void; onSelectDay: (day: string) => void }) {
  const nextDay = weekdays.find((day) => children.some((child) => (orders[child.id]?.[day] || []).length > 0)) || weekdays[0];
  const nextDayOpen = isOrderDeadlineOpen(nextDay);
  const reminderMessage = getReminderMessage(nextDay);
  const openPayments = completedOrders.filter((order) => order.status === 'offen');
  const paidOrders = completedOrders.filter((order) => order.status === 'bezahlt');
  const openTotal = openPayments.reduce((sum, order) => sum + order.total, 0);
  const deadlineText = nextDayOpen ? formatOrderDeadline(nextDay) : 'fixiert';

  function goToOrder() {
    onSelectChild(children[0]?.id || initialChildren[0].id);
    onSelectDay(nextDay);
    onNavigate('bestellen');
  }

  return <div className="space-y-7"><div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between"><div><h2 className="text-3xl font-black tracking-tight text-slate-950 md:text-4xl">Guten Morgen, Stefan! 👋</h2><p className="mt-2 text-lg text-slate-500">Schön, dass du da bist. Hier ist dein Überblick für heute.</p></div><div className="flex gap-3"><div className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 font-semibold text-slate-700 shadow-sm ring-1 ring-slate-200"><Icon name="calendar" /> {new Date().toLocaleDateString('de-DE', { day: '2-digit', month: 'long', year: 'numeric' })}</div><button className="relative rounded-2xl bg-white p-3 shadow-sm ring-1 ring-slate-200"><Icon name="bell" className="h-5 w-5" />{openPayments.length > 0 && <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">{openPayments.length}</span>}</button></div></div><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4"><StatCard label="Offene Bestellungen" value={openPayments.length} hint="Zahlungen oder Prüfung offen" icon="basket" tone="violet" /><StatCard label="Bezahlt" value={paidOrders.length} hint="bereits bestätigt" icon="check" tone="emerald" /><StatCard label="Bestellfrist endet" value={nextDayOpen ? nextDay : 'Fixiert'} hint={deadlineText} icon="clock" tone="orange" /><StatCard label="Offener Betrag" value={money(openTotal)} hint={`${openPayments.length} offene Bestellung(en)`} icon="euro" tone="blue" /></div><Card className="rounded-[2rem] border-0 bg-white/90 shadow-sm ring-1 ring-slate-200"><CardContent className="p-6"><h3 className="text-2xl font-black tracking-tight">Schnellzugriff</h3><div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-6"><QuickActionCard icon="basket" title="Neue Bestellung" desc="Für deine Kinder bestellen" tone="orange" onClick={goToOrder} /><QuickActionCard icon="children" title="Kinder verwalten" desc="Kinder hinzufügen oder bearbeiten" tone="yellow" onClick={() => onNavigate('kinder')} /><QuickActionCard icon="payment" title="Zahlungen prüfen" desc="Zahlungsstatus einsehen" tone="blue" onClick={() => onNavigate('zahlung')} /><QuickActionCard icon="chart" title="Statistiken" desc="Übersichten und Auswertungen" tone="violet" onClick={() => onNavigate('statistiken')} /><QuickActionCard icon="school" title="Ausgabe / Bäckerei" desc="Produktionsliste anzeigen" tone="emerald" onClick={() => onNavigate('schule')} /><QuickActionCard icon="admin" title="Adminbereich" desc="Verwaltung und Einstellungen" tone="slate" onClick={() => onNavigate('admin')} /></div></CardContent></Card><div className="rounded-[1.75rem] border border-yellow-200 bg-gradient-to-r from-yellow-50 to-orange-50 p-5 shadow-sm"><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div className="flex items-start gap-4"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-yellow-400 text-xl shadow-sm"><Icon name="warning" /></span><div><p className="text-lg font-black text-slate-950">{reminderMessage}</p><p className="mt-1 text-sm text-slate-600">Bitte rechtzeitig bestellen, damit wir alles gut planen können.</p></div></div><Button onClick={goToOrder} className="rounded-2xl bg-yellow-400 px-6 py-6 font-black text-slate-950 hover:bg-yellow-500">Jetzt bestellen <Icon name="chevron" className="ml-2" /></Button></div></div></div>;
}

export default function PausenappMvpPrototype() {
  const [user, setUser] = useState<any>(null);
  const [loginEmail, setLoginEmail] = useState(ADMIN_EMAIL);
  const [loginPassword, setLoginPassword] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('start');
  const [children, setChildren] = useState<Child[]>(initialChildren);
  const [activeChildId, setActiveChildId] = useState(initialChildren[0].id);
  const [activeDay, setActiveDay] = useState(weekdays[0]);
  const [orders, setOrders] = useState<OrderMap>(initialOrders);
  const [completedOrders, setCompletedOrders] = useState<CompletedOrder[]>(initialCompletedOrders);
  const [newChildName, setNewChildName] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('Überweisung');
  const [lastConfirmation, setLastConfirmation] = useState('');
  const [lastOrder, setLastOrder] = useState<CompletedOrder | null>(null);
  const [menuProducts, setMenuProducts] = useState<Product[]>(fallbackProducts);
  const [newProduct, setNewProduct] = useState({ name: '', price: '', tags: '', desc: '' });
  const [adminOrderSearch, setAdminOrderSearch] = useState('');
  const [adminFilter, setAdminFilter] = useState('alle');
  const [copiedText, setCopiedText] = useState('');
  const [paypalStatus, setPaypalStatus] = useState('');
  const [backendNotice, setBackendNotice] = useState(isSupabaseConfigured ? 'Supabase verbunden' : 'Demo-Modus');
  const [dataLoading, setDataLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    async function loadSupabaseData() {
      if (!supabase) return;
      setDataLoading(true);
      try {
        const { data: authData, error: authError } = await supabase.auth.getUser();
        if (authError) throw authError;
        let loadedUser: any = null;
        if (authData?.user) {
          const { data: profile, error: profileError } = await supabase.from('profiles').select('id, email, full_name, role').eq('id', authData.user.id).maybeSingle();
          if (profileError) throw profileError;
          loadedUser = createUserFromProfile(authData.user, profile);
          setUser(loadedUser);
        }
        const { data: productData, error: productError } = await supabase.from('products').select('id, name, description, price, tags, active').eq('active', true).order('name');
        if (productError) throw productError;
        if (Array.isArray(productData) && productData.length) {
          const normalizedProducts = productData.map(normalizeProduct);
          setMenuProducts(normalizedProducts);
        }
        if (loadedUser?.id) await loadChildrenAndOrders(loadedUser);
        setBackendNotice(loadedUser ? 'Kinder, Produkte und Bestellungen aus Supabase geladen' : 'Produkte aus Supabase geladen. Bitte einloggen.');
      } catch (error) {
        setBackendNotice(getNetworkErrorMessage(error));
      } finally {
        setDataLoading(false);
      }
    }
    loadSupabaseData();
  }, []);

  async function loadChildrenAndOrders(loadedUser = user) {
    if (!supabase || !functionNeedsRealUser(loadedUser)) return;
    try {
      const { data: childData, error: childError } = await supabase.from('children').select('id, name, school, class_name, allergies').eq('parent_id', loadedUser.id).order('created_at', { ascending: true });
      if (childError) throw childError;
      const normalizedChildren = Array.isArray(childData) && childData.length ? childData.map(normalizeChild) : initialChildren;
      setChildren(normalizedChildren);
      setActiveChildId(normalizedChildren[0]?.id || initialChildren[0].id);
      const { data: orderData, error: orderError } = await supabase.from('orders').select('id, child_id, school, weekday, total, payment_method, payment_reference, status, confirmation_email_sent, created_at').eq('parent_id', loadedUser.id).order('created_at', { ascending: false }).limit(25);
      if (orderError) throw orderError;
      if (Array.isArray(orderData)) setCompletedOrders(orderData.map((order) => normalizeCompletedOrder(order, normalizedChildren.find((child) => child.id === order.child_id), loadedUser)));
    } catch (error) {
      setBackendNotice(`Daten konnten nicht geladen werden: ${getNetworkErrorMessage(error)}`);
    }
  }

  async function loginWithPassword() {
    if (!supabase) return setBackendNotice('Supabase ist nicht konfiguriert.');
    setAuthLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email: loginEmail, password: loginPassword });
      if (error) throw error;
      const { data: profile, error: profileError } = await supabase.from('profiles').select('id, email, full_name, role').eq('id', data.user.id).maybeSingle();
      if (profileError) throw profileError;
      const loggedInUser = createUserFromProfile(data.user, profile);
      setUser(loggedInUser);
      await loadChildrenAndOrders(loggedInUser);
      setBackendNotice('Login erfolgreich. Kinder und Bestellungen geladen');
    } catch (error) {
      setBackendNotice(`Login fehlgeschlagen: ${getNetworkErrorMessage(error)}`);
    } finally {
      setAuthLoading(false);
    }
  }

  async function logout() {
    try { if (supabase) await supabase.auth.signOut(); } catch (error) { setBackendNotice(getNetworkErrorMessage(error)); }
    setUser(null);
    setBackendNotice('Abgemeldet');
  }

  const hasRealSupabaseUser = functionNeedsRealUser(user);
  const currentUser = hasRealSupabaseUser ? user : demoUser;
  const navigationItems = getNavigationItems(currentUser);
  const activeChild = children.find((child) => child.id === activeChildId) || children[0];
  const weeklyTotal = useMemo(() => calculateWeeklyTotal(orders, menuProducts), [orders, menuProducts]);
  const activeDayTotal = calculateChildDayTotal(activeChild.id, activeDay, orders, menuProducts);
  const dayItems = orders[activeChild.id]?.[activeDay] || [];
  const activeDeadlineOpen = isOrderDeadlineOpen(activeDay);
  const activeOrderEditable = activeDeadlineOpen;
  const schoolRows = buildSchoolRows(children, orders, activeDay, menuProducts);
  const productSummary = buildProductSummary(children, orders, activeDay, menuProducts);
  const paidRevenue = completedOrders.filter((order) => order.status === 'bezahlt').reduce((sum, order) => sum + order.total, 0);
  const openRevenue = completedOrders.filter((order) => order.status === 'offen').reduce((sum, order) => sum + order.total, 0);
  const filteredAdminOrders = useMemo(() => {
    let list = filterOrdersBySearch(completedOrders, adminOrderSearch);
    if (adminFilter === 'offen') list = list.filter((order) => order.status === 'offen');
    if (adminFilter === 'bezahlt') list = list.filter((order) => order.status === 'bezahlt');
    return list;
  }, [completedOrders, adminOrderSearch, adminFilter]);
  const parentOrderStats = useMemo(() => getParentOrderStats(completedOrders), [completedOrders]);
  const adminTodoSummary = useMemo(() => ({ openPayments: parentOrderStats.openCount, productionItems: productSummary.reduce((sum, row) => sum + row.quantity, 0), emailsOpen: completedOrders.filter((order) => order.email !== 'gesendet').length }), [completedOrders, parentOrderStats.openCount, productSummary]);

  async function copyToClipboard(text: string, label = 'Text') {
    try { await navigator.clipboard.writeText(String(text)); setCopiedText(`${label} kopiert`); } catch { setCopiedText(`${label} konnte nicht kopiert werden`); }
  }

  function openPayPalPayment() {
    const opened = window.open(PAYPAL_PAYMENT_LINK, '_blank', 'noopener,noreferrer');
    setPaypalStatus(opened ? 'PayPal wurde geöffnet. Bitte dort Betrag und Verwendungszweck angeben.' : 'PayPal konnte vom Browser nicht automatisch geöffnet werden. Bitte Link kopieren und im Browser öffnen.');
  }

  function toggleProduct(productId: string) {
    if (!activeOrderEditable) return setBackendNotice(`Bestellungen für ${activeDay} sind nach der Frist fixiert.`);
    setOrders((prev) => {
      const childOrders = prev[activeChild.id] || {};
      const current = childOrders[activeDay] || [];
      const next = current.includes(productId) ? current.filter((id) => id !== productId) : [...current, productId];
      return { ...prev, [activeChild.id]: { ...childOrders, [activeDay]: next } };
    });
  }

  async function addChild() {
    const trimmed = newChildName.trim();
    if (!trimmed) return;
    const localChild: Child = { id: slugify(trimmed) || `kind-${children.length + 1}`, name: trimmed, school: 'Grundschule Zentrum', className: '1A', allergies: 'keine' };
    if (supabase && functionNeedsRealUser(user)) {
      try {
        const { data, error } = await supabase.from('children').insert({ parent_id: user.id, name: localChild.name, school: localChild.school, class_name: localChild.className, allergies: localChild.allergies }).select('id, name, school, class_name, allergies').single();
        if (error) throw error;
        const savedChild = normalizeChild(data);
        setChildren((prev) => [...prev, savedChild]);
        setActiveChildId(savedChild.id);
        setBackendNotice('Kind in Supabase gespeichert');
      } catch (error) { setBackendNotice(`Kind konnte nicht gespeichert werden: ${getNetworkErrorMessage(error)}`); }
    } else {
      setChildren((prev) => [...prev, localChild]);
      setActiveChildId(localChild.id);
      setBackendNotice('Kind lokal hinzugefügt. Für Supabase bitte einloggen.');
    }
    setNewChildName('');
  }

  async function invokeEmailFunction(type: string, payload: any) {
    if (!supabase) return { sent: false, reason: 'Supabase ist nicht verbunden.' };
    try {
      const { error } = await supabase.functions.invoke(EMAIL_FUNCTION_NAME, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: { type, payload } });
      if (error) return { sent: false, reason: error.message };
      return { sent: true };
    } catch (error) { return { sent: false, reason: getNetworkErrorMessage(error) }; }
  }

  async function sendOrderEmails({ savedOrder, selectedProducts }: { savedOrder: CompletedOrder; selectedProducts: Product[] }) {
    const payload = buildOrderEmailPayload({ order: savedOrder, child: activeChild, day: activeDay, selectedProducts });
    const result = await invokeEmailFunction('order_confirmation', payload);
    if (result.sent && isUuid(savedOrder.id)) {
      try { await supabase!.from('orders').update({ confirmation_email_sent: true }).eq('id', savedOrder.id); } catch (error) { setBackendNotice(getNetworkErrorMessage(error)); }
    }
    return result;
  }

  async function sendReminderEmail(type: string, order: CompletedOrder | null = null) {
    const payload = order ? { adminEmail: ADMIN_EMAIL, parentName: order.parent, parentEmail: order.parentEmail, childName: order.child, weekday: order.day, total: order.total, paymentMethod: order.payment, paymentReference: order.paymentReference } : { adminEmail: ADMIN_EMAIL, parentName: currentUser.name, parentEmail: currentUser.email, weekday: activeDay, deadline: formatOrderDeadline(activeDay) };
    setIsSaving(true);
    const result = await invokeEmailFunction(type, payload);
    setIsSaving(false);
    setBackendNotice(result.sent ? 'Reminder-Mail gesendet' : `Reminder konnte nicht gesendet werden: ${result.reason}`);
  }

  async function saveOrderToSupabase(localOrder: CompletedOrder) {
    const selectedProducts = dayItems.map((productId) => menuProducts.find((product) => product.id === productId)).filter(Boolean) as Product[];
    if (!supabase || !functionNeedsRealUser(user)) return { saved: false, reason: 'Keine echte Supabase-Session aktiv.', selectedProducts };
    if (!selectedProducts.length) return { saved: false, reason: 'Keine Produkte ausgewählt.', selectedProducts };
    if (!selectedProducts.every((product) => isUuid(product.id))) return { saved: false, reason: 'Mindestens ein Produkt stammt noch aus Demo-Daten.', selectedProducts };
    try {
      const childId = isUuid(activeChild.id) ? activeChild.id : null;
      if (!childId) return { saved: false, reason: 'Kind ist noch nicht in Supabase gespeichert.', selectedProducts };
      const { data: insertedOrder, error: orderError } = await supabase.from('orders').insert({ parent_id: user.id, child_id: childId, school: activeChild.school, delivery_date: getNextDeliveryDate(activeDay), weekday: activeDay, total: activeDayTotal, payment_method: selectedPayment, payment_reference: localOrder.paymentReference, status: localOrder.status, confirmation_email_sent: false, bakery_email_sent: false }).select('id').single();
      if (orderError) throw orderError;
      const orderItems = selectedProducts.map((product) => ({ order_id: insertedOrder.id, product_id: product.id, product_name: product.name, quantity: 1, unit_price: product.price }));
      const { error: itemError } = await supabase.from('order_items').insert(orderItems);
      if (itemError) throw itemError;
      return { saved: true, orderId: insertedOrder.id, selectedProducts };
    } catch (error) { return { saved: false, reason: getNetworkErrorMessage(error), selectedProducts }; }
  }

  async function confirmOrder() {
    if (!activeDeadlineOpen) return setLastConfirmation(`Bestellfrist für ${activeDay} ist abgelaufen. Bitte wähle einen anderen Tag.`);
    if (!dayItems.length) return setLastConfirmation('Bitte wähle zuerst mindestens ein Produkt aus.');
    const localOrder: CompletedOrder = { id: `ord-${1000 + completedOrders.length + 1}`, parent: currentUser.name, parentEmail: currentUser.email, child: activeChild.name, school: activeChild.school, day: activeDay, total: activeDayTotal, payment: selectedPayment, paymentReference: createPaymentReference({ child: activeChild, day: activeDay }), status: selectedPayment === 'Stripe' || selectedPayment === 'Kreditkarte' ? 'bezahlt' : 'offen', email: 'vorgemerkt' };
    setIsSaving(true);
    setPaypalStatus('');
    try {
      const result = await saveOrderToSupabase(localOrder);
      const savedOrder = result.saved ? { ...localOrder, id: result.orderId! } : localOrder;
      let finalOrder = { ...savedOrder };
      if (selectedPayment === 'PayPal') {
        setPaypalStatus('Bestellung gespeichert. Bitte öffne PayPal über den Button unten und gib dort Betrag und Verwendungszweck an.');
        finalOrder = { ...savedOrder, status: 'offen' };
      }
      const emailResult = result.saved ? await sendOrderEmails({ savedOrder: finalOrder, selectedProducts: result.selectedProducts }) : { sent: false, reason: result.reason };
      finalOrder = { ...finalOrder, email: emailResult.sent ? 'gesendet' : 'vorgemerkt' };
      setCompletedOrders((prev) => [finalOrder, ...prev]);
      setLastOrder(finalOrder);
      setLastConfirmation(emailResult.sent ? 'Bestellung erfolgreich!' : `Bestellung gespeichert, aber E-Mail/Supabase-Hinweis: ${emailResult.reason}`);
      setBackendNotice(emailResult.sent ? 'Bestellung gespeichert und E-Mails gesendet' : 'Bestellung gespeichert, E-Mail-Versand offen');
      await loadChildrenAndOrders(user);
    } catch (error) {
      setLastOrder(null);
      setLastConfirmation(`Fehler beim Speichern: ${getNetworkErrorMessage(error)}`);
    } finally { setIsSaving(false); }
  }

  async function markPaid(orderId: string) {
    const orderToConfirm = completedOrders.find((order) => order.id === orderId);
    setCompletedOrders((prev) => prev.map((order) => (order.id === orderId ? { ...order, status: 'bezahlt' } : order)));
    if (supabase && functionNeedsRealUser(user) && isUuid(orderId)) {
      setIsSaving(true);
      try {
        const { error } = await supabase.from('orders').update({ status: 'bezahlt' }).eq('id', orderId);
        if (error) throw error;
        if (orderToConfirm) await invokeEmailFunction('payment_confirmed', { orderId, parentName: orderToConfirm.parent, parentEmail: orderToConfirm.parentEmail, childName: orderToConfirm.child, total: orderToConfirm.total, paymentReference: orderToConfirm.paymentReference, adminEmail: ADMIN_EMAIL });
        setBackendNotice('Zahlung bestätigt');
      } catch (error) { setBackendNotice(`Zahlungsstatus konnte nicht gespeichert werden: ${getNetworkErrorMessage(error)}`); }
      finally { setIsSaving(false); }
    } else setBackendNotice('Zahlung lokal als bezahlt markiert');
  }

  async function addProduct() {
    const name = newProduct.name.trim();
    const price = Number.parseFloat(String(newProduct.price).replace(',', '.'));
    if (!name || Number.isNaN(price) || price <= 0) return;
    const product = { id: slugify(name), name, price, tags: newProduct.tags.split(',').map((tag) => tag.trim()).filter(Boolean), desc: newProduct.desc || 'Beschreibung folgt.' };
    setMenuProducts((prev) => [...prev, product]);
    setNewProduct({ name: '', price: '', tags: '', desc: '' });
  }

  function printBakeryList() { window.print(); }

  return <div className="min-h-screen bg-[#f7f9fc] text-slate-950"><div className="grid min-h-screen gap-6 p-4 lg:grid-cols-[280px_1fr] lg:p-6"><aside className="hidden rounded-[2rem] bg-white p-5 shadow-sm ring-1 ring-slate-200 lg:flex lg:flex-col"><div className="flex items-center gap-3 px-2 py-3"><span className="text-4xl">🥪</span><div><p className="text-2xl font-black tracking-tight">Pausenapp</p><p className="text-sm font-medium text-slate-500">Einfach. Bestellt.</p></div></div><nav className="mt-8 space-y-2">{navigationItems.map(([id, iconName, label]) => <button key={id} onClick={() => setActiveTab(id)} className={`flex w-full items-center gap-4 rounded-2xl px-5 py-4 text-left text-base font-bold transition ${activeTab === id ? 'bg-gradient-to-r from-indigo-500 to-violet-500 text-white shadow-lg shadow-indigo-100' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-950'}`}><Icon name={id === 'start' ? 'home' : iconName} className="h-5 w-5" />{label === 'Ausgabe' ? 'Ausgabe / Bäckerei' : label}</button>)}</nav><div className="mt-auto rounded-3xl bg-slate-50 p-4 ring-1 ring-slate-200"><div className="flex items-center gap-3"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500 font-black text-white">SE</span><div><p className="font-extrabold">{currentUser.name}</p><p className="text-sm font-semibold text-indigo-600">{currentUser.role === 'admin' ? 'Administrator' : 'Elternkonto'}</p></div></div><div className="mt-4 border-t pt-4">{hasRealSupabaseUser ? <button onClick={logout} className="text-sm font-bold text-slate-500 hover:text-slate-950">↪ Abmelden</button> : <span className="text-xs font-semibold text-amber-700">Lokaler Vorschaumodus</span>}</div></div></aside><div className="min-w-0"><div className="mb-4 rounded-[1.5rem] bg-white p-3 shadow-sm ring-1 ring-slate-200 lg:hidden"><div className="mb-3 flex items-center justify-between px-2"><div className="flex items-center gap-2"><span className="text-2xl">🥪</span><span className="font-black">Pausenapp</span></div><span className="text-xs font-semibold text-slate-500">{currentUser.role === 'admin' ? 'Admin' : 'Eltern'}</span></div><nav className="grid grid-cols-3 gap-2 sm:grid-cols-6">{navigationItems.map(([id, iconName, label]) => <button key={id} onClick={() => setActiveTab(id)} className={`rounded-2xl px-3 py-3 text-xs font-bold transition ${activeTab === id ? 'bg-slate-950 text-white' : 'bg-slate-50 text-slate-600'}`}><Icon name={id === 'start' ? 'home' : iconName} className="mx-auto mb-1 h-4 w-4" />{label}</button>)}</nav></div><main className="rounded-[2rem] bg-white/90 p-5 shadow-sm ring-1 ring-slate-200 lg:p-8"><div className="mb-4 flex flex-wrap items-center gap-2 text-xs font-semibold text-slate-400"><span>{dataLoading ? 'Daten werden geladen...' : backendNotice}</span>{!hasRealSupabaseUser && <span className="rounded-full bg-amber-100 px-3 py-1 text-amber-800">Speichern nur lokal</span>}</div>{!hasRealSupabaseUser && <Card className="mb-6 rounded-2xl border-2 border-amber-300 bg-amber-50 shadow-sm"><CardContent className="grid gap-3 p-5 md:grid-cols-[1fr_1fr_auto] md:items-end"><div className="md:col-span-3"><h2 className="text-xl font-bold text-amber-950">Supabase Login erforderlich</h2><p className="mt-1 text-sm text-amber-800">Bitte mit deinem Supabase-Admin-User einloggen. Falls Supabase blockiert ist, läuft die App lokal weiter.</p></div><div><label className="text-sm font-semibold text-slate-600">Admin E-Mail</label><Input value={loginEmail} onChange={(event) => setLoginEmail(event.target.value)} className="mt-2 rounded-xl" /></div><div><label className="text-sm font-semibold text-slate-600">Passwort</label><Input type="password" value={loginPassword} onChange={(event) => setLoginPassword(event.target.value)} className="mt-2 rounded-xl" /></div><Button onClick={loginWithPassword} disabled={authLoading || !loginPassword} className="rounded-xl">{authLoading ? 'Login...' : 'Einloggen'}</Button></CardContent></Card>}<motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}>{activeTab === 'start' && <ParentHome children={children} orders={orders} completedOrders={completedOrders} onNavigate={setActiveTab} onSelectChild={setActiveChildId} onSelectDay={setActiveDay} />}{activeTab === 'bestellen' && <div className="grid gap-6 lg:grid-cols-[280px_1fr]"><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-5"><h2 className="mb-4 text-xl font-bold">Kind auswählen</h2><div className="space-y-2">{children.map((child) => <button key={child.id} onClick={() => setActiveChildId(child.id)} className={`w-full rounded-xl border p-4 text-left transition ${activeChildId === child.id ? 'border-slate-950 bg-slate-950 text-white' : 'border-slate-200 bg-white hover:bg-slate-50'}`}><p className="font-bold">{child.name}</p><p className={`text-sm ${activeChildId === child.id ? 'text-slate-200' : 'text-slate-500'}`}>{child.className} · {child.school}</p></button>)}</div></CardContent></Card><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-5 md:p-7"><div className="mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between"><div><p className="text-sm font-semibold text-emerald-700">Bestellung für {activeChild.name}</p><h2 className="text-2xl font-bold">Pause für {activeDay}</h2><div className="mt-2 rounded-xl bg-yellow-50 p-3 text-sm font-semibold text-yellow-800">{getReminderMessage(activeDay)}</div><p className="mt-2 text-sm text-slate-500">Allergien: {activeChild.allergies}</p></div><Button onClick={() => setActiveTab('zahlung')} disabled={!activeDeadlineOpen} className="rounded-xl">{activeDeadlineOpen ? `Zur Zahlung · ${money(activeDayTotal)}` : 'Frist abgelaufen'} <Icon name="chevron" className="ml-1 h-4 w-4" /></Button></div><div className="mb-6 flex flex-wrap gap-2">{weekdays.map((day) => <button key={day} onClick={() => setActiveDay(day)} className={`rounded-full px-4 py-2 text-sm font-semibold ${activeDay === day ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'}`}>{day.slice(0, 2)}</button>)}</div><div className="grid gap-4 md:grid-cols-2">{menuProducts.map((product) => { const selected = dayItems.includes(product.id); return <button key={product.id} onClick={() => toggleProduct(product.id)} disabled={!activeOrderEditable} className={`rounded-2xl border p-5 text-left transition ${selected ? 'border-emerald-600 bg-emerald-50' : 'border-slate-200 bg-white hover:border-slate-300'} ${!activeOrderEditable ? 'cursor-not-allowed opacity-60' : ''}`}><div className="flex items-start justify-between gap-4"><div><h3 className="font-bold">{product.name}</h3><p className="mt-1 text-sm text-slate-500">{product.desc}</p></div><div className="text-right"><p className="font-bold">{money(product.price)}</p>{selected && <span className="ml-auto mt-2 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-600 text-sm font-bold text-white"><Icon name="check" /></span>}</div></div><div className="mt-4 flex flex-wrap gap-2">{product.tags.map((tag) => <span key={tag} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">{tag}</span>)}</div></button>; })}</div></CardContent></Card></div>}{activeTab === 'zahlung' && <div className="grid gap-6 lg:grid-cols-[1fr_360px]"><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><h2 className="text-2xl font-bold">Bestellung bezahlen</h2><p className="mt-2 text-slate-600">Wähle die Zahlungsart. Bei PayPal und Überweisung bleibt die Bestellung offen, bis der Admin bestätigt.</p><div className="mt-6 grid gap-4 md:grid-cols-2">{paymentMethods.map((method) => { const isLive = livePaymentMethods.includes(method); return <button key={method} onClick={() => setSelectedPayment(method)} className={`rounded-2xl border p-5 text-left ${selectedPayment === method ? 'border-emerald-600 bg-emerald-50' : 'border-slate-200 bg-white'}`}><div className="flex items-start justify-between gap-3"><p className="text-lg font-bold">{method}</p>{!isLive && <span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-500">Demo</span>}</div><p className="mt-1 text-sm text-slate-500">{method === 'PayPal' ? 'PayPal-Link öffnen und Betrag/Verwendungszweck angeben.' : method === 'Überweisung' ? 'Admin bestätigt nach Zahlungseingang.' : 'Demo-Zahlungsart.'}</p></button>; })}{selectedPayment === 'PayPal' && <div className="mt-2 rounded-2xl border border-blue-200 bg-blue-50 p-5 ring-1 ring-blue-100 md:col-span-2"><p className="text-sm font-semibold text-blue-900">PayPal Checkout</p><Button type="button" onClick={openPayPalPayment} className="mt-4 rounded-xl bg-blue-700 text-white hover:bg-blue-800">PayPal öffnen</Button><div className="mt-3 rounded-xl bg-white p-3 text-xs text-blue-900"><p className="break-all font-mono">{PAYPAL_PAYMENT_LINK}</p><button type="button" onClick={() => copyToClipboard(PAYPAL_PAYMENT_LINK, 'PayPal-Link')} className="mt-2 rounded-lg bg-blue-100 px-3 py-1 font-semibold text-blue-800">Link kopieren</button></div>{paypalStatus && <p className="mt-3 rounded-xl bg-white p-3 text-sm font-semibold text-blue-900">{paypalStatus}</p>}</div>}{selectedPayment === 'Überweisung' && <div className="mt-2 rounded-2xl border bg-white p-5 ring-1 ring-slate-200 md:col-span-2"><p className="text-sm font-semibold text-slate-600">Überweisungsdaten</p><div className="mt-3 grid gap-2 text-sm"><div className="flex justify-between gap-3"><span className="text-slate-500">Empfänger</span><span className="font-semibold">{BANK_RECIPIENT}</span></div><div className="flex justify-between gap-3"><span className="text-slate-500">IBAN</span><span className="flex items-center gap-2 font-mono font-semibold">{BANK_IBAN}<button onClick={() => copyToClipboard(BANK_IBAN, 'IBAN')} className="rounded-full bg-slate-100 px-2 py-1 text-xs font-sans text-slate-700">Kopieren</button></span></div><div className="flex justify-between gap-3"><span className="text-slate-500">BIC</span><span className="font-mono">{BANK_BIC || 'nicht erforderlich'}</span></div></div></div>}</div><Button onClick={confirmOrder} disabled={isSaving || !activeDeadlineOpen} className="mt-6 rounded-xl">{isSaving ? 'Speichere...' : 'Jetzt bestellen und bestätigen'}</Button>{lastConfirmation && <p className="mt-4 rounded-xl bg-amber-50 p-4 text-sm font-medium text-amber-800">{lastConfirmation}</p>}{lastOrder && <div className="mt-6 rounded-2xl bg-emerald-50 p-6 text-emerald-900 shadow-sm"><div className="flex items-center gap-3 text-lg font-bold"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-600 text-white">✓</span>Bestellung erfolgreich</div><p className="mt-3 text-sm">{lastOrder.child} · {lastOrder.day}</p><p className="text-sm">Gesamt: {money(lastOrder.total)}</p><p className="mt-4 text-sm font-semibold">Verwendungszweck</p><p className="text-xs font-bold text-red-600">WICHTIG: exakt so angeben!</p><div className="mt-1 flex flex-col gap-2 rounded-lg bg-white p-2 sm:flex-row sm:items-center sm:justify-between"><p className="font-mono text-sm">{lastOrder.paymentReference}</p><Button onClick={() => copyToClipboard(lastOrder.paymentReference, 'Verwendungszweck')} variant="outline" className="rounded-xl">Kopieren</Button></div>{lastOrder.payment === 'PayPal' && <Button type="button" onClick={openPayPalPayment} className="mt-4 rounded-xl bg-blue-700 text-white hover:bg-blue-800">Jetzt mit PayPal bezahlen</Button>}</div>}</CardContent></Card><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><h3 className="text-xl font-bold">Zusammenfassung</h3><p className="mt-4 text-sm text-slate-500">Kind</p><p className="font-semibold">{activeChild.name}</p><p className="mt-4 text-sm text-slate-500">Tag</p><p className="font-semibold">{activeDay}</p><p className="mt-4 text-sm text-slate-500">Produkte</p><p className="font-semibold">{dayItems.length ? dayItems.map((id) => menuProducts.find((product) => product.id === id)?.name).filter(Boolean).join(', ') : 'Keine Produkte gewählt'}</p><div className="mt-6 rounded-2xl bg-slate-950 p-5 text-white"><p className="text-sm text-slate-300">Gesamt</p><p className="text-3xl font-bold">{money(activeDayTotal)}</p></div></CardContent></Card></div>}{activeTab === 'kinder' && <Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><h2 className="mb-4 text-2xl font-bold">Kinder verwalten</h2><div className="mb-6 flex gap-2"><Input value={newChildName} onChange={(event) => setNewChildName(event.target.value)} placeholder="Name des Kindes" className="rounded-xl" /><Button onClick={addChild} className="rounded-xl"><Icon name="plus" className="mr-1 h-4 w-4" /> Hinzufügen</Button></div><div className="grid gap-4 md:grid-cols-2">{children.map((child) => <div key={child.id} className="rounded-2xl border bg-white p-5"><h3 className="text-lg font-bold">{child.name}</h3><p className="text-slate-500">{child.school}</p><p className="mt-2 text-sm">{child.className} · Allergien: {child.allergies}</p></div>)}</div></CardContent></Card>}{activeTab === 'statistiken' && <div className="space-y-6"><div className="grid gap-4 md:grid-cols-4"><StatCard label="Bestellungen" value={parentOrderStats.count} hint="bisher erfasst" icon="basket" /><StatCard label="Bezahlt" value={money(parentOrderStats.paidTotal)} hint="bereits bestätigt" icon="payment" /><StatCard label="Offen" value={money(parentOrderStats.openTotal)} hint="noch zu bezahlen" icon="mail" /><StatCard label="Kinder" value={children.length} hint="im Account" icon="user" /></div><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><h2 className="mb-4 text-2xl font-bold">Meine Bestellungen</h2><div className="space-y-3">{completedOrders.map((order) => <div key={order.id} className="rounded-2xl border bg-white p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="font-bold">{order.child} · {order.day}</p><p className="text-sm text-slate-500">{order.payment} · {money(order.total)}</p>{order.paymentReference && <p className="mt-2 font-mono text-xs text-slate-600">{order.paymentReference}</p>}</div><span className={`w-fit rounded-full px-3 py-1 text-xs font-bold ${order.status === 'bezahlt' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>{order.status}</span></div></div>)}</div></CardContent></Card></div>}{activeTab === 'schule' && <Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><div className="mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between"><div><p className="text-sm font-semibold text-emerald-700">Ausgabeansicht</p><h2 className="text-2xl font-bold">Bestellungen für {activeDay}</h2></div><div className="flex flex-wrap gap-2">{weekdays.map((day) => <button key={day} onClick={() => setActiveDay(day)} className={`rounded-full px-4 py-2 text-sm font-semibold ${activeDay === day ? 'bg-slate-950 text-white' : 'bg-slate-100'}`}>{day.slice(0, 2)}</button>)}</div></div><div className="grid gap-3">{schoolRows.length ? schoolRows.map(({ child, items, total }) => <div key={child.id} className="flex items-center justify-between rounded-2xl border bg-white p-4"><div><p className="font-bold">{child.name} · {child.className}</p><p className="text-sm text-slate-500">{items.join(', ')} · {money(total)}</p></div><Button variant="outline" className="rounded-xl">Ausgegeben</Button></div>) : <p className="rounded-2xl bg-white p-5 text-slate-500">Keine Bestellungen für diesen Tag.</p>}</div></CardContent></Card>}{currentUser.role === 'admin' && activeTab === 'admin' && <div className="space-y-6"><div className="grid gap-4 md:grid-cols-4"><StatCard label="Admin-Umsatz" value={money(paidRevenue + openRevenue)} hint="inkl. offener Zahlungen" icon="chart" /><StatCard label="Offene Zahlungen" value={adminTodoSummary.openPayments} hint={money(openRevenue)} icon="payment" /><StatCard label="Produktion heute" value={adminTodoSummary.productionItems} hint={`Artikel für ${activeDay}`} icon="basket" /><StatCard label="Offene E-Mails" value={adminTodoSummary.emailsOpen} hint={`Admin: ${ADMIN_EMAIL}`} icon="mail" /></div><Card className="rounded-2xl border-0 bg-gradient-to-r from-emerald-50 to-orange-50 shadow-sm"><CardContent className="p-6"><h2 className="text-2xl font-bold">Heute zu erledigen</h2><div className="mt-4 grid gap-3 md:grid-cols-3"><div className="rounded-2xl bg-white p-4"><p className="text-sm text-slate-500">Zahlungen prüfen</p><p className="mt-1 text-xl font-bold">{adminTodoSummary.openPayments} offen</p></div><div className="rounded-2xl bg-white p-4"><p className="text-sm text-slate-500">Bäckerei informieren</p><p className="mt-1 text-xl font-bold">{adminTodoSummary.productionItems} Artikel</p></div><div className="rounded-2xl bg-white p-4"><p className="text-sm text-slate-500">Reminder</p><Button onClick={() => sendReminderEmail('deadline_reminder')} disabled={isSaving} className="mt-2 rounded-xl">Frist-Reminder senden</Button></div></div></CardContent></Card><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><div className="mb-4 flex flex-col gap-3 md:flex-row md:items-end md:justify-between"><div><h2 className="text-2xl font-bold">Zahlungen verwalten</h2><p className="mt-1 text-sm text-slate-500">Suche nach Verwendungszweck, Kind, Eltern-Mail, Status oder Zahlungsart.</p></div><div className="w-full md:w-96"><label className="text-sm font-semibold text-slate-600">Suche</label><Input value={adminOrderSearch} onChange={(event) => setAdminOrderSearch(event.target.value)} placeholder="z. B. PAUSE-..., Lena, offen" className="mt-2 rounded-xl" /></div></div><div className="mb-3 flex flex-col gap-3 text-sm text-slate-500 md:flex-row md:items-center md:justify-between"><div className="flex gap-2"><Button variant={adminFilter === 'alle' ? 'default' : 'outline'} onClick={() => setAdminFilter('alle')}>Alle</Button><Button variant={adminFilter === 'offen' ? 'default' : 'outline'} onClick={() => setAdminFilter('offen')}>Offen</Button><Button variant={adminFilter === 'bezahlt' ? 'default' : 'outline'} onClick={() => setAdminFilter('bezahlt')}>Bezahlt</Button></div><span>{filteredAdminOrders.length} von {completedOrders.length} Bestellungen</span></div><div className="overflow-x-auto rounded-2xl border bg-white"><table className="w-full text-left text-sm"><thead className="bg-slate-100 text-slate-600"><tr><th className="p-4">Bestellung</th><th className="p-4">Kind</th><th className="p-4">E-Mail</th><th className="p-4">Zahlung</th><th className="p-4">Referenz</th><th className="p-4">Status</th><th className="p-4">Aktion</th></tr></thead><tbody>{filteredAdminOrders.length ? filteredAdminOrders.map((order) => <tr key={order.id} className="border-t"><td className="p-4 font-semibold">{order.id}</td><td className="p-4">{order.child}</td><td className="p-4">{order.parentEmail}</td><td className="p-4">{order.payment} · {money(order.total)}</td><td className="p-4 font-mono text-xs">{order.paymentReference || '–'}</td><td className="p-4"><span className={`rounded-full px-3 py-1 text-xs font-bold ${order.status === 'bezahlt' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>{order.status}</span></td><td className="p-4">{order.status === 'offen' ? <div className="flex flex-col gap-2"><Button onClick={() => markPaid(order.id)} variant="outline" className="rounded-xl">Als bezahlt markieren</Button><Button onClick={() => sendReminderEmail('payment_reminder', order)} variant="outline" className="rounded-xl">Zahlungs-Reminder</Button></div> : '–'}</td></tr>) : <tr><td className="p-4 text-slate-500" colSpan={7}>Keine Bestellung gefunden.</td></tr>}</tbody></table></div></CardContent></Card><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><h2 className="mb-4 text-2xl font-bold">Menü verwalten</h2><div className="mb-6 grid gap-3 rounded-2xl bg-slate-50 p-4 ring-1 ring-slate-200 md:grid-cols-[1.2fr_0.7fr_1fr_1.4fr_auto]"><Input value={newProduct.name} onChange={(event) => setNewProduct((prev) => ({ ...prev, name: event.target.value }))} placeholder="Produktname" className="rounded-xl" /><Input value={newProduct.price} onChange={(event) => setNewProduct((prev) => ({ ...prev, price: event.target.value }))} placeholder="Preis z. B. 3,20" className="rounded-xl" /><Input value={newProduct.tags} onChange={(event) => setNewProduct((prev) => ({ ...prev, tags: event.target.value }))} placeholder="Tags, z. B. vegan" className="rounded-xl" /><Input value={newProduct.desc} onChange={(event) => setNewProduct((prev) => ({ ...prev, desc: event.target.value }))} placeholder="Beschreibung" className="rounded-xl" /><Button onClick={addProduct} disabled={isSaving} className="rounded-xl">Hinzufügen</Button></div><div className="space-y-3">{menuProducts.map((product) => <div key={product.id} className="rounded-2xl border bg-white p-4"><p className="font-bold">{product.name} · {money(product.price)}</p><p className="text-sm text-slate-500">{product.desc}</p></div>)}</div></CardContent></Card><Card className="rounded-2xl border-0 shadow-sm"><CardContent className="p-6"><div className="mb-4 flex items-center justify-between"><div><h2 className="text-2xl font-bold">Produktionsliste für die Bäckerei</h2><p className="text-slate-500">Zusammenfassung für {activeDay}.</p></div><div className="flex flex-wrap gap-2"><Button onClick={printBakeryList} variant="outline" className="rounded-xl">PDF / Drucken</Button></div></div><div className="overflow-hidden rounded-2xl border bg-white"><table className="w-full text-left text-sm"><thead className="bg-slate-100 text-slate-600"><tr><th className="p-4">Produkt</th><th className="p-4">Menge</th></tr></thead><tbody>{productSummary.length ? productSummary.map((row) => <tr key={row.product} className="border-t"><td className="p-4 font-semibold">{row.product}</td><td className="p-4">{row.quantity}</td></tr>) : <tr><td className="p-4 text-slate-500" colSpan={2}>Keine Produkte für diesen Tag.</td></tr>}</tbody></table></div></CardContent></Card></div>}</motion.div></main></div></div></div>;
}
