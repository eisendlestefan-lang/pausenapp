import React from 'react';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default' | 'outline' | 'ghost' };

export function Button({ className = '', variant = 'default', ...props }: Props) {
  const base = 'inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-50';
  const styles = variant === 'outline'
    ? 'border border-slate-200 bg-white text-slate-800 hover:bg-slate-50'
    : variant === 'ghost'
      ? 'bg-transparent text-slate-700 hover:bg-slate-100'
      : 'bg-slate-950 text-white hover:bg-slate-800';
  return <button className={`${base} ${styles} ${className}`} {...props} />;
}
