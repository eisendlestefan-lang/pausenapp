import { createClient } from '@supabase/supabase-js';

export const env = {
  supabaseUrl: import.meta.env.VITE_SUPABASE_URL || '',
  supabaseAnonKey: import.meta.env.VITE_SUPABASE_ANON_KEY || '',
  adminEmail: import.meta.env.VITE_ADMIN_EMAIL || 'eisendlestefan@gmail.com',
  adminName: import.meta.env.VITE_ADMIN_NAME || 'Stefan Eisendle',
  bakeryEmail: import.meta.env.VITE_BAKERY_EMAIL || import.meta.env.VITE_ADMIN_EMAIL || 'eisendlestefan@gmail.com',
  paypalLink: import.meta.env.VITE_PAYPAL_PAYMENT_LINK || '',
  bankRecipient: import.meta.env.VITE_BANK_RECIPIENT || 'Raiffeisenkasse Wipptal',
  bankIban: import.meta.env.VITE_BANK_IBAN || '',
  bankBic: import.meta.env.VITE_BANK_BIC || '',
  emailFunctionName: import.meta.env.VITE_EMAIL_FUNCTION_NAME || 'email-versand'
};

export const isSupabaseConfigured = Boolean(env.supabaseUrl && env.supabaseAnonKey);
export const supabase = isSupabaseConfigured ? createClient(env.supabaseUrl, env.supabaseAnonKey) : null;
